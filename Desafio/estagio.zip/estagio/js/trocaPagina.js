function trocaPagina(op){
	switch(op){
		case index:
			break;
		
	}
	
}
